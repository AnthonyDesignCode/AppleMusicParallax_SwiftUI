//
//  ContentView.swift
//  Parallax_SwiftUI
//
//  Created by Anthony Codes on 12/10/2020.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        SearchView()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

struct SearchView: View {
    
    var edges = UIApplication.shared.windows.first?.safeAreaInsets
    @State var opacity : Double = 0
    
    var body: some View {
        //Parallax Scroll
        ZStack(alignment: Alignment(horizontal: .center, vertical: .top)) {
            ScrollView(.vertical, showsIndicators: false) {
                VStack {
                    //GeometryReader
                    GeometryReader{reader in
                        VStack {
                            //This is the main Images (Artist Profile Image.)
                            Image("p1")
                                .resizable()
                                .aspectRatio(contentMode: .fill)
                                .frame(width: UIScreen.main.bounds.width, height: reader.frame(in: .global).minY > 0 ? reader.frame(in: .global).minY + (UIScreen.main.bounds.height / 2.2) : UIScreen.main.bounds.height / 2.2) //This is creating a default width.
                                .offset(y: -reader.frame(in: .global).minY) // This is adjusting the view postion when scrolling.
                            
                                //Changing the NavBar when scrolling.
                                .onChange(of: reader.frame(in: .global).minY){value in
                                    //First we need to check if you are at the top.
                                    let offset = value + (UIScreen.main.bounds.height / 2.2)
                                    if offset < 80 {
                                        //Ranging from 0 - 80
                                        if offset > 0 {
                                            //When do we need to add the opacity?
                                            let opacity_value = (80 - offset) / 80
                                            self.opacity = Double(opacity_value)
                                            return
                                        } //We are not adding else yet because this would mean add full opacity.
                                        self.opacity = 1
                                    }else {
                                        self.opacity = 0
                                }
                            }
                        }
                    }
                    //Now we need to set a default height.
                    .frame(height: UIScreen.main.bounds.height / 2.2)
                    
                    //Making the List of songs.
                    VStack(spacing: 10){
                        //Fist we need the add some simple data. 👇
                        ForEach(albums,id: \.album_name){album in
                            HStack(spacing: 15){
                                Image("\(album.album_cover)")
                                    .resizable()
                                    .aspectRatio(contentMode: .fill)
                                    .frame(width: 55, height: 55)
                                    .cornerRadius(15)
                                VStack(alignment: .leading, spacing: 5) {
                                    Text("\(album.album_name)")
                                    Text("\(album.album_author)")
                                        .font(.caption)
                                }
                                Spacer(minLength: 0)
                            }
                            .padding(.horizontal)
                        }
                    }
                    .padding(.vertical)
                    .background(Color.white)
                }
            }
            //Creating the NavBar
            HStack{
                Button(action: {}) {
                    HStack(spacing: 8) {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 22, weight: .bold))
                        Text("Search")
                            .fontWeight(.semibold)
                    }
                }
                Spacer(minLength: 0)
                Button(action: {}) {
                    //Creating a MenuIcon
                    HStack(spacing: 5) {
                        Image(systemName: "circle.fill")
                            .resizable()
                            .frame(width: 10, height: 10)
                            //.foregroundColor(.white)
                        Image(systemName: "circle.fill")
                            .resizable()
                            .frame(width: 10, height: 10)
                            //.foregroundColor(.white)
                        Image(systemName: "circle.fill")
                            .resizable()
                            .frame(width: 10, height: 10)
                            //.foregroundColor(.white)
                    }
                }
            }
            .padding()
            .foregroundColor(opacity > 0.6 ? .red : .white)
            .padding(.top,edges!.top) // top edge is ignored
            .background(Color.white.opacity(opacity))
            .shadow(color: Color.black.opacity(opacity > 0.8 ? 0.1 : 0), radius: 5, x: 0, y: 5)
        }
        .ignoresSafeArea(.all, edges: .top)
    }
}

// Sample Data...

struct Album{

    var album_name : String
    var album_author : String
    var album_cover : String
}

var albums = [

    //Album(album_name: "Hollywood's Bleeding", album_author: "Post Malone", album_cover: "p1"),
    Album(album_name: "Patient", album_author: "Post Malone", album_cover: "p2"),
    Album(album_name: "Hollywood's Bleeding", album_author: "Post Malone", album_cover: "p3"),
    Album(album_name: "Over Now", album_author: "Post Malone", album_cover: "p4"),
    Album(album_name: "Bloody valentine", album_author: "Machine Gun Kelly", album_cover: "p5"),
    Album(album_name: "Started From the Bottom", album_author: "Drake", album_cover: "p6"),
    Album(album_name: "Heartless", album_author: "The Weekend", album_cover: "p7"),
    Album(album_name: "White Iverson", album_author: "Post Malone", album_cover: "p8"),
    Album(album_name: "Circles", album_author: "Post Malone", album_cover: "p9"),
    Album(album_name: "Better Now", album_author: "Post Malone", album_cover: "p10"),
    Album(album_name: "The Motion", album_author: "Drake", album_cover: "p11"),
    Album(album_name: "Don't Matter To Me", album_author: "Drake", album_cover: "p12"),
    Album(album_name: "Blinding Lights", album_author: "The Weekend", album_cover: "p13"),
    Album(album_name: "Forget me too", album_author: "Machine Gun Kelly", album_cover: "p14"),
    
]
