//
//  Parallax_SwiftUIApp.swift
//  Parallax_SwiftUI
//
//  Created by Anthony Codes on 12/10/2020.
//

import SwiftUI

@main
struct Parallax_SwiftUIApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
